import os
directory=os.getcwd()
print(directory)
